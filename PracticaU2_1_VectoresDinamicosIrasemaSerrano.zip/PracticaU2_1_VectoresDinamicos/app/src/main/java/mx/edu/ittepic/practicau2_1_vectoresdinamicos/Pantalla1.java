package mx.edu.ittepic.practicau2_1_vectoresdinamicos;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Pantalla1 extends AppCompatActivity {

    TextView mensaje;
    ListView lista;
    ArrayList arr = new ArrayList();
    Intent ventana;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla1);
        setTitle("Tareas");
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ventana = new Intent(Pantalla1.this, Pantalla2.class);
                startActivityForResult(ventana, 1);
            }
        });

        mensaje = findViewById(R.id.mensaje);
        lista = findViewById(R.id.listareas);

        hacerlista();

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String[] split = arr.get(position).toString().split("&&");
                ventana = new Intent(Pantalla1.this, Pantalla3.class);
                ventana.putExtra("tarea", split);
                startActivityForResult(ventana, 2);
            }
        });
    }

    private void hacerlista() {
        if (arr.size() != 0){
            ArrayList ordenados = new ArrayList();
            for (int i=1; i<=20; i++){
                for (int j=0; j<arr.size(); j++){
                    String[] split = arr.get(j).toString().split("&&");
                    if (i == Integer.parseInt(split[0])){
                        ordenados.add(arr.get(j).toString());
                        break;
                    }
                }
            }
            arr = ordenados;
            String[] nombres = new String[arr.size()];
            for (int i=0; i<arr.size(); i++){
                String[] split = arr.get(i).toString().split("&&");
                nombres[i] = split[1];
            }
            mensaje.setVisibility(View.INVISIBLE);
            ArrayAdapter tareas = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, nombres);
            lista.setAdapter(tareas);
        }else {
            lista.setAdapter(null);
            mensaje.setVisibility(View.VISIBLE);
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        switch (resultCode){
            case  1:
                String tareaG = data.getStringExtra("tarea");
                arr.add(tareaG);
                hacerlista();
                break;
            case 2:
                int id = data.getIntExtra("id", 1);
                for (int j=0; j<arr.size(); j++){
                    String[] split = arr.get(j).toString().split("&&");
                    if (id == Integer.parseInt(split[0])){
                        arr.remove(j);
                        break;
                    }
                }
                hacerlista();
                break;
            case 3:
                String tarea = data.getStringExtra("tarea");
                int idTarea = data.getIntExtra("id", 1);
                for (int j=0; j<arr.size(); j++){
                    String[] split = arr.get(j).toString().split("&&");
                    if (idTarea == Integer.parseInt(split[0])){
                        arr.remove(j);
                        arr.add(tarea);
                        break;
                    }
                }
                hacerlista();
                break;
        }
    }
}
