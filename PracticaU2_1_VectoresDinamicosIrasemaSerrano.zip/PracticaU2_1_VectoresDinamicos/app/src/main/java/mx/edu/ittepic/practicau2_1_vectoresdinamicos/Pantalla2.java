package mx.edu.ittepic.practicau2_1_vectoresdinamicos;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Pantalla2 extends AppCompatActivity {
    EditText ct1, ct2, ct3, ct4, capturar;
    Button guardar;
    String[] tarea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla2);
        setTitle("CAPTURA DE TAREAS");

        ct1 = findViewById(R.id.titulo);
        ct2 = findViewById(R.id.fecha);
        ct3 = findViewById(R.id.materia);
        ct4 = findViewById(R.id.descripcion);

        guardar = findViewById(R.id.btnguradar);
        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder msj = new AlertDialog.Builder(Pantalla2.this);
                msj.setTitle("Posiciòn").setMessage("En que posiciòn decea guardar su tarea?");

                capturar = new  EditText(Pantalla2.this);
                capturar.setInputType(InputType.TYPE_CLASS_NUMBER);
                capturar.setHint("Escribe una posicion del 1 al 20");
                msj.setView(capturar);

                msj.setPositiveButton("Aceptar",  new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        guardar();
                        dialog.dismiss();
                    }
                });

                try {
                    capturar.setText(tarea[0]);
                    guardar();
                }catch (Exception e){
                    msj.show();
                }
            }
        });

        try{
            tarea = getIntent().getStringArrayExtra("tarea");
            ct1.setText(tarea[1]);
            ct2.setText(tarea[2]);
            ct3.setText(tarea[3]);
            ct4.setText(tarea[4]);
        }catch (Exception e){ }
    }
    private void guardar(){
        String info;
        info = capturar.getText().toString()+"&&"+ct1.getText().toString()+"&&"+ct2.getText().toString()+"&&"+ct3.getText().toString()+"&&"+ct4.getText().toString();
        Intent datosRetorno = new Intent();
        datosRetorno.putExtra("tarea", info);
        setResult(1, datosRetorno);
        finish();
    }
}
