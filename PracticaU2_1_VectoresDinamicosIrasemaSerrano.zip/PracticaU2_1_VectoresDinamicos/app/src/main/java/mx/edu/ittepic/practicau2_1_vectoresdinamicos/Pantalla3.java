package mx.edu.ittepic.practicau2_1_vectoresdinamicos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Pantalla3 extends AppCompatActivity {
    TextView tv1, tv2, tv3, tv4;
    Button borrar, regresar, actualizar;
    String[] datos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Detalle de Tarea");
        setContentView(R.layout.activity_pantalla3);

        tv1 = findViewById(R.id.titulov);
        tv2 = findViewById(R.id.fechav);
        tv3 = findViewById(R.id.materiav);
        tv4 = findViewById(R.id.descripcionv);
        borrar = findViewById(R.id.borrar);
        regresar = findViewById(R.id.regresar);
        actualizar = findViewById(R.id.actualizar);

        datos = getIntent().getExtras().getStringArray("tarea");

        tv1.setText(datos[1]);
        tv2.setText(datos[2]);
        tv3.setText(datos[3]);
        tv4.setText(datos[4]);

        borrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent datosRetorno = new Intent();
                int id = Integer.parseInt(datos[0]);
                datosRetorno.putExtra("id", id);
                setResult(2, datosRetorno);
                finish();
            }
        });

        regresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        actualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent actualizar = new Intent(Pantalla3.this, Pantalla2.class);
                actualizar.putExtra("tarea", datos );
                startActivityForResult(actualizar, 1);
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        switch (resultCode){
            case  1:
                String info = data.getStringExtra("tarea");
                datos = info.toString().split("&&");
                tv1.setText(datos[1]);
                tv2.setText(datos[2]);
                tv3.setText(datos[3]);
                tv4.setText(datos[4]);

                Intent datosRetorno = new Intent();
                datosRetorno.putExtra("tarea", info);
                int id = Integer.parseInt(datos[0]);
                datosRetorno.putExtra("id", id);
                setResult(3, datosRetorno);
                break;
        }
    }
}
