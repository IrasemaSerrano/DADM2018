package mx.edu.ittepic.adicional3_u2_elfacilito_irasemaserrano;

import android.graphics.Color;
import android.provider.CalendarContract;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView nombre, edad, genero, nomradiogroup, titulo, espacio;
    EditText nom, ed;
    Spinner gene;
    RadioGroup estadocivil;
    RadioButton solter, casad;
    LinearLayout botones;
    TableLayout layin;
    TableRow uno, dos, tres;
    Button enviar, limpiar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("U2_Adicional3_ElFacilio");
        setContentView(R.layout.activity_main);

        nombre = new TextView(this);
        edad = new TextView(this);
        genero = new TextView(this);
        nomradiogroup = new TextView(this);
        titulo = new TextView(this);
        espacio = new TextView(this);
        nom = new EditText(this);
        ed =  new EditText(this);
        gene = new Spinner(this);
        estadocivil = new RadioGroup(this);
        solter = new RadioButton(this);
        casad = new RadioButton(this);
        layin = findViewById(R.id.layin);
        botones = new LinearLayout(this);
        uno = new TableRow(this);
        dos = new TableRow(this);
        tres = new TableRow(this);
        enviar = new Button(this);
        limpiar = new Button(this);

        titulo.setText("DATOS GENERALES");
        titulo.setTextSize(20);
        titulo.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        titulo.setPadding(0,0,0,30);

        layin.addView(titulo);

        nombre.setText("Nombre: ");
        nom.setHint("Iniciando con apellidos");

        edad.setText("Edad: ");
        ed.setHint("debe ser numero");
        ed.setInputType(InputType.TYPE_CLASS_NUMBER);

        genero.setText("Genero: ");
        String[] contenido = {"Mujer", "Hombre"};
        ArrayAdapter mh = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, contenido);
        gene.setAdapter(mh);

        uno.addView(nombre);
        uno.addView(nom);
        uno.setPadding(0,0,0, 15);
        layin.addView(uno);
        dos.addView(edad);
        dos.addView(ed);
        dos.setPadding(0,0,0,30);
        layin.addView(dos);
        tres.addView(genero);
        tres.addView(gene);
        tres.setPadding(0,0,0,30);
        layin.addView(tres);

        nomradiogroup.setText("Edo Civil");
        nomradiogroup.setPadding(0,0,0,30);
        solter.setText("Soltero/Soltera");
        solter.setPadding(0,0,0,25);
        casad.setText("Casado/Casada");
        estadocivil.addView(nomradiogroup);
        estadocivil.addView(solter);
        estadocivil.addView(casad);
        estadocivil.setPadding(0,0,0, 80);

        layin.addView(estadocivil);

        enviar.setText("Enviar");
        enviar.setBackgroundColor(Color.RED);
        enviar.setPadding(60,0,60,0);
        limpiar.setText("Limpiar");
        limpiar.setBackgroundColor(Color.RED);
        limpiar.setPadding(60,0,60,0);
        espacio.setText("          ");
        botones.addView(enviar);
        botones.addView(espacio);
        botones.addView(limpiar);
        botones.setPadding(8,0,0,0);
        layin.addView(botones);

        layin.setPadding(40, 40, 40, 10);


        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder mensaje = new AlertDialog.Builder(MainActivity.this);
                if (gene.getSelectedItem().equals("Mujer")){
                    if (solter.isChecked()){
                        mensaje.setTitle("ENVIANDO...").setMessage("Los datos: "+nom.getText().toString()+", "+ed.getText().toString()+", "+"Mujer, Soltera, "+"se estàn enviando al sitio WEB.");
                        mensaje.show();
                    }else {
                        mensaje.setTitle("ENVIANDO...").setMessage("Los datos: "+nom.getText().toString()+", "+ed.getText().toString()+", "+"Mujer, Casada, "+"se estàn enviando al sitio WEB.");
                        mensaje.show();
                    }
                }else {
                    if (solter.isChecked()) {
                        mensaje.setTitle("ENVIANDO...").setMessage("Los datos: " + nom.getText().toString() + ", " + ed.getText().toString() + ", " + "Hombre, Soltero, " + "se estàn enviando al sitio WEB.");
                        mensaje.show();
                    }else {
                        mensaje.setTitle("ENVIANDO...").setMessage("Los datos: " + nom.getText().toString() + ", " + ed.getText().toString() + ", " + "Hombre, Casado, " + "se estàn enviando al sitio WEB.");
                        mensaje.show();
                    }
                }
            }
        });

        limpiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nom.setText("");
                ed.setText("");
            }
        });
    }
}
